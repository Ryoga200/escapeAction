using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace StarterAssets
{
public class playerController : MonoBehaviour
{ 
     public GameObject area;
     GameObject GM;
    gameController _GM;
    static Vector3 direction = new Vector3(0, -1, 0); 
    static Vector3 updirection = new Vector3(0, 1, 0); 
    Ray ray ;
    RaycastHit hit;
    GameObject Player;
    ThirdPersonController third;
    public GameObject time;
    timerController _timer;
   float keyTime;
    // Start is called before the first frame update
    void Start()
    {GM=GameObject.FindWithTag("GameController");
       _GM=GM.GetComponent<gameController>();
       Player=GameObject.FindWithTag("Player");
       third=Player.GetComponent<ThirdPersonController>();
       keyTime=0.0f;
       _timer=time.GetComponent<timerController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    } 
      private void OnControllerColliderHit(ControllerColliderHit hit)
        {
            Debug.Log(hit);
            if(hit.gameObject.tag=="key"){
               if((_timer.minute*60 + _timer.seconds)-keyTime>0.5){
                     _GM.key++;
               GameObject prnt=hit.transform.parent.gameObject;
               Destroy (prnt.gameObject);
               keyTime=_timer.minute*60 +_timer.seconds;
               }
               
            }
            if(hit.gameObject.tag=="capsule"){
                 CancelInvoke("down1");
                 CancelInvoke("down2");
                 CancelInvoke("down3");
               third.MoveSpeed =8.0f;
               third.SprintSpeed=20.0f;
                Invoke("down1", 5);
                 Destroy (hit.gameObject);
            }if(hit.gameObject.tag=="head"){
                GameObject prnt=hit.transform.parent.gameObject;
               Destroy (prnt.gameObject);
            }
            if(hit.gameObject.tag=="clear"){
               _GM.isClear=true;
            }
        }
   private void down1(){
      third.MoveSpeed =6.0f;
      third.SprintSpeed=15.0f;
      Invoke("down2", 5);
   }
   private void down2(){
      third.MoveSpeed =4.0f;
      third.SprintSpeed =10.0f;
      Invoke("down3", 5);
   }
   private void down3(){
      third.MoveSpeed =2.0f;
      third.SprintSpeed =5.0f;
   }
}
}