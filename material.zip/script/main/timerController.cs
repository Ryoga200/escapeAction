using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class timerController : MonoBehaviour
{
[SerializeField]
	public int minute;
	[SerializeField]
	public float seconds;
    public bool isClear=true;
	//　前のUpdateの時の秒数
	//　タイマー表示用テキスト
	void Start () {
		minute = 0;
		seconds = 0f;
	}
 
	void Update () {
        if(isClear){
            seconds += Time.deltaTime;
		if(seconds >= 60f) {
			minute++;
			seconds = seconds - 60;
		}
        }
		
	}
}
