using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using TMPro;
[RequireComponent(typeof(NavMeshAgent))]
public class enemyController : MonoBehaviour
{
    GameObject player;
    GameObject GM;
    gameController _game;
    private NavMeshAgent navMeshAgent;
    // Start is called before the first frame update
    void Start()
    {
        // NavMeshAgentを保持しておく
        player=GameObject.FindWithTag("Player");
        navMeshAgent = GetComponent<NavMeshAgent>();
        GM=GameObject.FindWithTag("GameController");
        _game=GM.GetComponent<gameController>();
    }

    // Update is called once per frame
    void Update()
    {
        // プレイヤーを目指して進む

        navMeshAgent.destination = player.transform.position;
        
    }
    private void OnCollisionEnter(Collision other) {
        if(other.gameObject.tag=="Player"){
            _game.collisionFlag=true;
        }
    }
}
