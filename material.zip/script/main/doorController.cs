using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class doorController : MonoBehaviour
{
    public Animator anime;
    // Start is called before the first frame update
    GameObject player;
    bool isTrigger=true;
    void Start()
    {
        player=GameObject.FindWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {
        if(isTrigger && Distance(player.transform.position.x,this.transform.position.x,player.transform.position.z,this.transform.position.z)<3.0f){
             Debug.Log("aa");
             anime.SetBool("isDoor", !anime.GetBool("isDoor"));
             isTrigger=false;
        }
    }
    public static double Distance(float x1, float x2,float y1,float y2)
    {
        float xDiff = x1 - x2;
        float yDiff = y1 - y2;
        return Math.Sqrt(xDiff * xDiff + yDiff * yDiff);
    }
}
