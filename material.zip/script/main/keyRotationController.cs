using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class keyRotationController : MonoBehaviour
{
    Vector3 origin;
    static Vector3 direction = new Vector3(0, -1, 0); 
    static Vector3 updirection = new Vector3(0, 1, 0); 
    Ray ray ;
    RaycastHit hit;
    public GameObject parent;
    bool isPosition=true;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
      Vector3 origin = new Vector3(transform.position.x, transform.position.y, transform.position.z);
         Ray ray =new Ray(origin, direction); 
           // Debug.DrawRay(ray.origin, ray.direction * 30, Color.red, 5.0f); // 長さ３０、赤色で５秒間可視化
        transform.Rotate(new Vector3(1.0f, 0.0f, 0.0f));
        if(isPosition || true){
        if(Physics.Raycast(ray, out hit,10.0f)){
            isPosition=false;
    		string name = hit.collider.gameObject.name; 
    	// 	Debug.Log(name); // コンソールに表示
        // Debug.DrawRay(ray.origin, ray.direction * 30, Color.red, 5.0f); // 長さ３０、赤色で５秒間可視化
        }else{
            parent.transform.position= new Vector3(parent.transform.position.x,parent.transform.position.y,parent.transform.position.z + 1.2f);
        }
        if(Physics.Raycast(origin,updirection, out hit,10.0f)){
            isPosition=false;
    		string name = hit.collider.gameObject.name; 
    		//Debug.Log(name); // コンソールに表示
             parent.transform.position= new Vector3(parent.transform.position.x,parent.transform.position.y,parent.transform.position.z + 1.2f);
        Debug.DrawRay(ray.origin, ray.direction * 30, Color.red, 5.0f); // 長さ３０、赤色で５秒間可視化
        }
        }
    }
    void OnTriggerStay(Collider other)
    {
         parent.transform.position= new Vector3(parent.transform.position.x,parent.transform.position.y,parent.transform.position.z + 1.2f);
    }
}
