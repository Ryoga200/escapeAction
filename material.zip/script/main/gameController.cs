using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;
using TMPro;
using Random = UnityEngine.Random;
using StarterAssets;
using UnityEngine.InputSystem;
public class gameController : MonoBehaviour
{
    // Start is called before the first frame update
    public int key=0;
    int maxX;
    int maxZ;
    public float span = 4f;
    private float currentTime = 0f;
    public GameObject capsule;
    public GameObject enemy;
    public GameObject player;
    public GameObject keyItem;
    public Terrain terrain;
    public GameObject Canvas;
    public TextMeshProUGUI statusText;
    public GameObject gameOverCanvas;
    public TextMeshProUGUI gameOverText;
    public TextMeshProUGUI gameScore;
    public bool collisionFlag=false;
    public GameObject door;
    public GameObject timer;
    private timerController _timer;
    public bool isClear=false;
    public GameObject clearCanvas;
    public TextMeshProUGUI clearText;
    public TextMeshProUGUI clearScore;
    private bool isGenerate=true;
    void Start()
    {
        maxX = (int)terrain.terrainData.size.x;
        maxZ = (int)terrain.terrainData.size.z;
        int i=0;
        for(i=0;i<5;i++){
        GameObject instance = (GameObject)Instantiate(keyItem);
        Vector3 keyTransform = KeySetVector3();
        instance.transform.position = keyTransform;
        }
        for(i=0;i<50;i++){
        GameObject instance = (GameObject)Instantiate(enemy);
        Vector3 enemyTransform = KeySetVector3();
        instance.transform.position = enemyTransform;
        }
        for(i=0;i<10;i++){
        GameObject instance = (GameObject)Instantiate(capsule);
        Vector3  enemyTransform = KeySetVector3();
        instance.transform.position = enemyTransform;
        }
        Cursor.lockState =  CursorLockMode.Locked;
        _timer=timer.GetComponent<timerController>();
    }

    // Update is called once per frame
    void Update()
    {  
        if(key<10){
            statusText.text = "鍵を"+key.ToString()+"/10個入手しました";
        }else{
            statusText.text = "ゴールへ向かいましょう";
            Destroy(door);
        }
        
        currentTime += Time.deltaTime;

        if(currentTime > span && isGenerate){
            //Debug.LogFormat ("{0}秒経過", span);
            generation();
            currentTime = 0f;
        }
        if(player.transform.position.y<-40 && !isClear){
            gameOverText.text="落下してしまった";
            gameScore.text="鍵を"+key.ToString()+"個入手しました";
            Canvas.SetActive(false);
            gameOverCanvas.SetActive(true);
            var _controller= player.GetComponent<CharacterController>();
            _controller.enabled = false;
            Cursor.lockState = CursorLockMode.None;
            isGenerate=false;
        }
        if(collisionFlag &&!isClear){
            gameOverText.text="敵にやられた";
            gameScore.text="鍵を"+key.ToString()+"個入手しました";
            Canvas.SetActive(false);
            gameOverCanvas.SetActive(true);
            var _controller= player.GetComponent<CharacterController>();
            _controller.enabled = false;
            Cursor.lockState = CursorLockMode.None;
            isGenerate=false;
        }
        if(isClear){
            float second=_timer.seconds;
            int minute=_timer.minute;
            _timer.isClear=false;
            clearText.text="ゲームをクリアした";
            clearScore.text="経過時間は"+minute.ToString()+"分"+second.ToString()+"秒です";
            Canvas.SetActive(false);
            clearCanvas.SetActive(true);
            var _controller= player.GetComponent<CharacterController>();
            _controller.enabled = false;
            Cursor.lockState = CursorLockMode.None;
            isGenerate=false;
        }
    }
    void generation(){
        GameObject instance = (GameObject)Instantiate(capsule);
        Vector3 capsuleTransform = SetVector3();
        instance.transform.position = capsuleTransform;
        GameObject instance2 = (GameObject)Instantiate(enemy);
        Vector3  enemyTransform = SetVector3();
        instance2.transform.position = enemyTransform;
        
        
    }
    Vector3 SetVector3()
    {
    float x;
    float z;
    float y;
    Vector3 position = player.transform.position; 
    do{
	// 0〜maxXの間で乱数を生成
	x = Random.Range(0, maxX);
	// 0〜maxZの間で乱数を生成
	z = Random.Range(0, maxZ);
	// 生成した数字を使って、Vector3を生成
    }while(Distance(position.x,x-50.37f,position.z,z-150)<7);
    y = terrain.terrainData.GetInterpolatedHeight(x / terrain.terrainData.size.x, z / terrain.terrainData.size.z);
	return new Vector3(x-50.37f, y-98.5f, z-150);
    }
    public static double Distance(float x1, float x2,float y1,float y2)
    {
        float xDiff = x1 - x2;
        float yDiff = y1 - y2;
        return Math.Sqrt(xDiff * xDiff + yDiff * yDiff);
    }
    Vector3 KeySetVector3(){
    float x;
    float z;
    float y;
    Vector3 position = player.transform.position; 
    do{
	// 0〜maxXの間で乱数を生成
	x = Random.Range(0, maxX);
	// 0〜maxZの間で乱数を生成
	z = Random.Range(0, maxZ);
	// 生成した数字を使って、Vector3を生成
    }while(z-150<-90 && x-50.37f>170-50.37f);
    y = terrain.terrainData.GetInterpolatedHeight(x / terrain.terrainData.size.x, z / terrain.terrainData.size.z);
	return new Vector3(x-50.37f, y-98.5f, z-150);
    }
}
