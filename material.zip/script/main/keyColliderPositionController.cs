using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class keyColliderPositionController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Transform myTransform = this.transform;
         myTransform.localPosition = new Vector3(-0.7f,0,0);
         myTransform.localRotation = Quaternion.Euler(30, 0, 90);
    }
}
