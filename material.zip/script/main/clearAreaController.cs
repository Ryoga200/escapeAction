using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class clearAreaController : MonoBehaviour
{
    public GameObject GM;
    gameController _game;
    // Start is called before the first frame update
    void Start()
    {
       GM=GameObject.FindWithTag("GameController");
       _game=GM.GetComponent<gameController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision other) {
        Debug.Log(other.gameObject);
        if(other.gameObject.tag=="Player"){
            _game.isClear=true;
        }
    } 
}
