using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class howToButton : MonoBehaviour
{
    public GameObject howTo;
    public GameObject title;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnClick()
    {

         howTo.SetActive(true);
         title.SetActive(false);
    }
}
