using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class hotToManager : MonoBehaviour
{
    int page;
    public RawImage image;
    public GameObject howTo;
    public GameObject title;
    public TextMeshProUGUI preText;
    public TextMeshProUGUI nextText;
    // Start is called before the first frame update
    void Start()
    {
        page=1;
    }

    // Update is called once per frame
    void Update()
    {
        if(page==1){
            preText.text="タイトルへ";
        }else{
            preText.text="戻る";
        }
        if(page==8){
            nextText.text="タイトルへ";
        }else{
            nextText.text="次へ";
        }
    }
    public void OnClickPre()
    {

        if(page==1){
        title.SetActive(true);
         howTo.SetActive(false);
        }else{
            page--;
        }
        image.texture=Resources.Load<Texture2D> ("image/"+page.ToString());
        
    }
    public void OnClickNext()
    {
        if(page==8){
        title.SetActive(true);
         howTo.SetActive(false);
         page=1;
        }else{
            page++;
        }
        image.texture=Resources.Load<Texture2D> ("image/"+page.ToString());
    
    }
}
